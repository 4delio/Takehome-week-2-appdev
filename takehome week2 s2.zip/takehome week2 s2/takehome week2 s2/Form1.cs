﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace takehome_week2_s2
{
    public partial class Form1 : Form
    {
        string hurufpencet = "1";
        public Form1()
        {
            InitializeComponent();
        }
        private void startbutton_Click(object sender, EventArgs e)
        {
            bool salah = false;
            string forbiden = "1234567890";
            string[] katakata = new string[5];
            foreach (char c in forbiden)
            {
                if (boxkata1.Text.Contains(c)||boxkata2.Text.Contains(c)||boxkata3.Text.Contains(c)||boxkata4.Text.Contains(c)||boxkata5.Text.Contains(c))
                {
                    salah = true;
                }
            }
            if (salah == true)
            {
                MessageBox.Show("Kata harus terdiri dari hanya huruf");
            }
            if (salah == false)
            {
                if (boxkata1.Text.Length == 0 || boxkata2.Text.Length == 0 || boxkata3.Text.Length == 0 || boxkata4.Text.Length == 0 || boxkata5.Text.Length == 0)
                {
                    MessageBox.Show("Tidak boleh ada kata yang kosong");
                    salah = true;
                }
            }
            if (salah == false)
            {
                if (boxkata1.Text.Length < 5 || boxkata2.Text.Length < 5 || boxkata3.Text.Length < 5 || boxkata4.Text.Length < 5 || boxkata5.Text.Length < 5 || boxkata1.Text.Length > 5 || boxkata2.Text.Length > 5 || boxkata3.Text.Length > 5 || boxkata4.Text.Length > 5 || boxkata5.Text.Length > 5)
                {
                    MessageBox.Show("Kata harus berjumlah 5 huruf,tidak boleh kurang dan lebih");
                    salah=true;
                }
            }
            if (salah == false)
            {
                if (boxkata1.Text == boxkata2.Text|| boxkata1.Text == boxkata3.Text|| boxkata1.Text == boxkata4.Text|| boxkata1.Text == boxkata5.Text|| boxkata2.Text == boxkata1.Text|| boxkata2.Text == boxkata3.Text|| boxkata2.Text == boxkata4.Text|| boxkata2.Text == boxkata5.Text|| boxkata3.Text == boxkata1.Text|| boxkata3.Text == boxkata2.Text|| boxkata3.Text == boxkata4.Text|| boxkata3.Text == boxkata5.Text|| boxkata4.Text == boxkata1.Text|| boxkata4.Text == boxkata2.Text|| boxkata4.Text == boxkata3.Text|| boxkata4.Text == boxkata5.Text|| boxkata5.Text == boxkata1.Text|| boxkata5.Text == boxkata2.Text|| boxkata5.Text == boxkata3.Text|| boxkata5.Text == boxkata4.Text)
                {
                    MessageBox.Show("Masing-masing kata harus berbeda dan tidak boleh sama");
                    salah = true;
                }
            }
            if (salah == false)
            {
                panelmain.Left -= 2000;
                panelutama.Left = 1000;
                katakata[0] = boxkata1.Text;
                katakata[1] = boxkata2.Text;
                katakata[2] = boxkata3.Text;
                katakata[3] = boxkata4.Text;
                katakata[4] = boxkata5.Text;
                Random random = new Random();
                int pilihankata = random.Next(0, 5);
                string pilihan = katakata[pilihankata];
                pilihan = pilihan.ToUpper();
                string[] kata = new string[5];
                int count = 0;
                foreach(char r in pilihan)
                {
                    kata[count] = r.ToString();
                    count++;
                }
                huruf1.Text = kata[0];
                huruf2.Text = kata[1];
                huruf3.Text = kata[2];
                huruf4.Text = kata[3];
                huruf5.Text = kata[4];
                answer.Text = pilihan;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panelutama.Left = 200;
            panelmain.Left += 2000;
            panelwin.Top -= 1000;
        }

        private void buttonQ_Click(object sender, EventArgs e)
        {
            hurufpencet = "Q";
        }

        private void buttonW_Click(object sender, EventArgs e)
        {
            hurufpencet = "W";
        }

        private void ButtonE_Click(object sender, EventArgs e)
        {
            hurufpencet = "E";
        }

        private void buttonR_Click(object sender, EventArgs e)
        {
            hurufpencet = "R";
        }

        private void buttonT_Click(object sender, EventArgs e)
        {
            hurufpencet = "T";
        }

        private void buttonY_Click(object sender, EventArgs e)
        {
            hurufpencet = "Y";
        }

        private void buttonU_Click(object sender, EventArgs e)
        {
            hurufpencet = "U";
        }

        private void buttonI_Click(object sender, EventArgs e)
        {
            hurufpencet = "I";
        }

        private void buttonO_Click(object sender, EventArgs e)
        {
            hurufpencet = "O";
        }

        private void buttonP_Click(object sender, EventArgs e)
        {
            hurufpencet = "P";
        }

        private void buttonA_Click(object sender, EventArgs e)
        {
            hurufpencet = "A";
        }

        private void buttonS_Click(object sender, EventArgs e)
        {
            hurufpencet = "S";
        }

        private void buttonD_Click(object sender, EventArgs e)
        {
            hurufpencet = "D";
        }

        private void buttonF_Click(object sender, EventArgs e)
        {
            hurufpencet = "F";
        }

        private void buttonG_Click(object sender, EventArgs e)
        {
            hurufpencet = "G";
        }

        private void buttonH_Click(object sender, EventArgs e)
        {
            hurufpencet = "H";
        }

        private void buttonJ_Click(object sender, EventArgs e)
        {
            hurufpencet = "J";
        }

        private void buttonK_Click(object sender, EventArgs e)
        {
            hurufpencet = "K";
        }

        private void buttonL_Click(object sender, EventArgs e)
        {
            hurufpencet = "L";
        }

        private void buttonZ_Click(object sender, EventArgs e)
        {
            hurufpencet = "Z";
        }

        private void buttonX_Click(object sender, EventArgs e)
        {
            hurufpencet = "X";
        }

        private void buttonC_Click(object sender, EventArgs e)
        {
            hurufpencet = "C";
        }

        private void buttonV_Click(object sender, EventArgs e)
        {
            hurufpencet = "V";
        }

        private void buttonB_Click(object sender, EventArgs e)
        {
            hurufpencet = "B";
        }

        private void buttonN_Click(object sender, EventArgs e)
        {
            hurufpencet = "N";
        }

        private void buttonM_Click(object sender, EventArgs e)
        {
            hurufpencet = "M";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (huruf1cover.Visible == false && huruf2cover.Visible == false && huruf3cover.Visible == false && huruf4cover.Visible == false && huruf5cover.Visible == false&&panelwin.Top < 0)
            {
                panelwin.Top += 10;
            }
            if (huruf1.Text.Contains(hurufpencet))
            {
                huruf1cover.Visible = false;
            }
            if (huruf2.Text.Contains(hurufpencet))
            {
                huruf2cover.Visible = false;
            }
            if (huruf3.Text.Contains(hurufpencet))
            {
                huruf3cover.Visible = false;
            }
            if (huruf4.Text.Contains(hurufpencet))
            {
                huruf4cover.Visible = false;
            }
            if (huruf5.Text.Contains(hurufpencet))
            {
                huruf5cover.Visible = false;
            }
            hurufpencet = "1";
        }

        private void buttonrestart_Click(object sender, EventArgs e)
        {
            panelmain.Left += 2000;
            panelutama.Left = 200;
            huruf1cover.Visible = true;
            huruf2cover.Visible = true;
            huruf3cover.Visible = true;
            huruf4cover.Visible = true;
            huruf5cover.Visible = true;
            panelwin.Top -= 1000;
        }

        private void buttonexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            panelmain.Left += 2000;
            panelutama.Left = 200;
            panelwin.Top = -1000;
            huruf1cover.Visible = true; huruf2cover.Visible = true; huruf3cover.Visible = true; huruf4cover.Visible = true; huruf5cover.Visible = true;
        }
    }
}
