﻿namespace takehome_week2_s2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.boxkata1 = new System.Windows.Forms.TextBox();
            this.labelkata1 = new System.Windows.Forms.Label();
            this.instruksi = new System.Windows.Forms.Label();
            this.labelkata2 = new System.Windows.Forms.Label();
            this.boxkata2 = new System.Windows.Forms.TextBox();
            this.labelkata3 = new System.Windows.Forms.Label();
            this.boxkata3 = new System.Windows.Forms.TextBox();
            this.labelkata4 = new System.Windows.Forms.Label();
            this.boxkata4 = new System.Windows.Forms.TextBox();
            this.labelkata5 = new System.Windows.Forms.Label();
            this.boxkata5 = new System.Windows.Forms.TextBox();
            this.startbutton = new System.Windows.Forms.Button();
            this.panelutama = new System.Windows.Forms.Panel();
            this.panelmain = new System.Windows.Forms.Panel();
            this.panelwin = new System.Windows.Forms.Panel();
            this.buttonexit = new System.Windows.Forms.Button();
            this.buttonrestart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.huruf5cover = new System.Windows.Forms.Label();
            this.huruf4cover = new System.Windows.Forms.Label();
            this.huruf3cover = new System.Windows.Forms.Label();
            this.huruf2cover = new System.Windows.Forms.Label();
            this.huruf1cover = new System.Windows.Forms.Label();
            this.buttonM = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonQ = new System.Windows.Forms.Button();
            this.huruf5 = new System.Windows.Forms.Label();
            this.huruf4 = new System.Windows.Forms.Label();
            this.huruf3 = new System.Windows.Forms.Label();
            this.huruf2 = new System.Windows.Forms.Label();
            this.huruf1 = new System.Windows.Forms.Label();
            this.gametime = new System.Windows.Forms.Timer(this.components);
            this.backbutton = new System.Windows.Forms.Button();
            this.answer = new System.Windows.Forms.Label();
            this.panelutama.SuspendLayout();
            this.panelmain.SuspendLayout();
            this.panelwin.SuspendLayout();
            this.SuspendLayout();
            // 
            // boxkata1
            // 
            this.boxkata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxkata1.Location = new System.Drawing.Point(248, 62);
            this.boxkata1.Margin = new System.Windows.Forms.Padding(4);
            this.boxkata1.Name = "boxkata1";
            this.boxkata1.Size = new System.Drawing.Size(124, 27);
            this.boxkata1.TabIndex = 0;
            // 
            // labelkata1
            // 
            this.labelkata1.AutoSize = true;
            this.labelkata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelkata1.Location = new System.Drawing.Point(173, 66);
            this.labelkata1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelkata1.Name = "labelkata1";
            this.labelkata1.Size = new System.Drawing.Size(54, 20);
            this.labelkata1.TabIndex = 1;
            this.labelkata1.Text = "kata 1";
            // 
            // instruksi
            // 
            this.instruksi.AutoSize = true;
            this.instruksi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instruksi.Location = new System.Drawing.Point(16, 17);
            this.instruksi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.instruksi.Name = "instruksi";
            this.instruksi.Size = new System.Drawing.Size(557, 25);
            this.instruksi.TabIndex = 2;
            this.instruksi.Text = "Masukkan 5 kata dengan panjang 5 huruf untuk memulai game";
            // 
            // labelkata2
            // 
            this.labelkata2.AutoSize = true;
            this.labelkata2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelkata2.Location = new System.Drawing.Point(173, 117);
            this.labelkata2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelkata2.Name = "labelkata2";
            this.labelkata2.Size = new System.Drawing.Size(54, 20);
            this.labelkata2.TabIndex = 4;
            this.labelkata2.Text = "kata 2";
            // 
            // boxkata2
            // 
            this.boxkata2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxkata2.Location = new System.Drawing.Point(248, 113);
            this.boxkata2.Margin = new System.Windows.Forms.Padding(4);
            this.boxkata2.Name = "boxkata2";
            this.boxkata2.Size = new System.Drawing.Size(124, 27);
            this.boxkata2.TabIndex = 3;
            // 
            // labelkata3
            // 
            this.labelkata3.AutoSize = true;
            this.labelkata3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelkata3.Location = new System.Drawing.Point(173, 166);
            this.labelkata3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelkata3.Name = "labelkata3";
            this.labelkata3.Size = new System.Drawing.Size(54, 20);
            this.labelkata3.TabIndex = 6;
            this.labelkata3.Text = "kata 3";
            // 
            // boxkata3
            // 
            this.boxkata3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxkata3.Location = new System.Drawing.Point(248, 162);
            this.boxkata3.Margin = new System.Windows.Forms.Padding(4);
            this.boxkata3.Name = "boxkata3";
            this.boxkata3.Size = new System.Drawing.Size(124, 27);
            this.boxkata3.TabIndex = 5;
            // 
            // labelkata4
            // 
            this.labelkata4.AutoSize = true;
            this.labelkata4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelkata4.Location = new System.Drawing.Point(173, 222);
            this.labelkata4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelkata4.Name = "labelkata4";
            this.labelkata4.Size = new System.Drawing.Size(54, 20);
            this.labelkata4.TabIndex = 8;
            this.labelkata4.Text = "kata 4";
            // 
            // boxkata4
            // 
            this.boxkata4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxkata4.Location = new System.Drawing.Point(248, 219);
            this.boxkata4.Margin = new System.Windows.Forms.Padding(4);
            this.boxkata4.Name = "boxkata4";
            this.boxkata4.Size = new System.Drawing.Size(124, 27);
            this.boxkata4.TabIndex = 7;
            // 
            // labelkata5
            // 
            this.labelkata5.AutoSize = true;
            this.labelkata5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelkata5.Location = new System.Drawing.Point(173, 272);
            this.labelkata5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelkata5.Name = "labelkata5";
            this.labelkata5.Size = new System.Drawing.Size(54, 20);
            this.labelkata5.TabIndex = 10;
            this.labelkata5.Text = "kata 5";
            // 
            // boxkata5
            // 
            this.boxkata5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxkata5.Location = new System.Drawing.Point(248, 269);
            this.boxkata5.Margin = new System.Windows.Forms.Padding(4);
            this.boxkata5.Name = "boxkata5";
            this.boxkata5.Size = new System.Drawing.Size(124, 27);
            this.boxkata5.TabIndex = 9;
            // 
            // startbutton
            // 
            this.startbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startbutton.Location = new System.Drawing.Point(154, 314);
            this.startbutton.Name = "startbutton";
            this.startbutton.Size = new System.Drawing.Size(249, 73);
            this.startbutton.TabIndex = 11;
            this.startbutton.Text = "Press Here To Start";
            this.startbutton.UseVisualStyleBackColor = true;
            this.startbutton.Click += new System.EventHandler(this.startbutton_Click);
            // 
            // panelutama
            // 
            this.panelutama.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panelutama.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelutama.Controls.Add(this.instruksi);
            this.panelutama.Controls.Add(this.startbutton);
            this.panelutama.Controls.Add(this.boxkata1);
            this.panelutama.Controls.Add(this.labelkata5);
            this.panelutama.Controls.Add(this.labelkata1);
            this.panelutama.Controls.Add(this.boxkata5);
            this.panelutama.Controls.Add(this.boxkata2);
            this.panelutama.Controls.Add(this.labelkata4);
            this.panelutama.Controls.Add(this.labelkata2);
            this.panelutama.Controls.Add(this.boxkata4);
            this.panelutama.Controls.Add(this.boxkata3);
            this.panelutama.Controls.Add(this.labelkata3);
            this.panelutama.Location = new System.Drawing.Point(997, 29);
            this.panelutama.Name = "panelutama";
            this.panelutama.Size = new System.Drawing.Size(590, 396);
            this.panelutama.TabIndex = 12;
            // 
            // panelmain
            // 
            this.panelmain.Controls.Add(this.answer);
            this.panelmain.Controls.Add(this.backbutton);
            this.panelmain.Controls.Add(this.huruf5cover);
            this.panelmain.Controls.Add(this.huruf4cover);
            this.panelmain.Controls.Add(this.huruf3cover);
            this.panelmain.Controls.Add(this.huruf2cover);
            this.panelmain.Controls.Add(this.huruf1cover);
            this.panelmain.Controls.Add(this.buttonM);
            this.panelmain.Controls.Add(this.buttonN);
            this.panelmain.Controls.Add(this.buttonB);
            this.panelmain.Controls.Add(this.buttonV);
            this.panelmain.Controls.Add(this.buttonC);
            this.panelmain.Controls.Add(this.buttonX);
            this.panelmain.Controls.Add(this.buttonZ);
            this.panelmain.Controls.Add(this.buttonL);
            this.panelmain.Controls.Add(this.buttonK);
            this.panelmain.Controls.Add(this.buttonJ);
            this.panelmain.Controls.Add(this.buttonH);
            this.panelmain.Controls.Add(this.buttonG);
            this.panelmain.Controls.Add(this.buttonF);
            this.panelmain.Controls.Add(this.buttonD);
            this.panelmain.Controls.Add(this.buttonS);
            this.panelmain.Controls.Add(this.buttonA);
            this.panelmain.Controls.Add(this.buttonP);
            this.panelmain.Controls.Add(this.buttonO);
            this.panelmain.Controls.Add(this.buttonI);
            this.panelmain.Controls.Add(this.buttonU);
            this.panelmain.Controls.Add(this.buttonY);
            this.panelmain.Controls.Add(this.buttonT);
            this.panelmain.Controls.Add(this.buttonR);
            this.panelmain.Controls.Add(this.buttonE);
            this.panelmain.Controls.Add(this.buttonW);
            this.panelmain.Controls.Add(this.buttonQ);
            this.panelmain.Controls.Add(this.huruf5);
            this.panelmain.Controls.Add(this.huruf4);
            this.panelmain.Controls.Add(this.huruf3);
            this.panelmain.Controls.Add(this.huruf2);
            this.panelmain.Controls.Add(this.huruf1);
            this.panelmain.Location = new System.Drawing.Point(3, 2);
            this.panelmain.Name = "panelmain";
            this.panelmain.Size = new System.Drawing.Size(988, 512);
            this.panelmain.TabIndex = 13;
            // 
            // panelwin
            // 
            this.panelwin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panelwin.Controls.Add(this.buttonexit);
            this.panelwin.Controls.Add(this.buttonrestart);
            this.panelwin.Controls.Add(this.label1);
            this.panelwin.Location = new System.Drawing.Point(3, 2);
            this.panelwin.Name = "panelwin";
            this.panelwin.Size = new System.Drawing.Size(988, 557);
            this.panelwin.TabIndex = 39;
            // 
            // buttonexit
            // 
            this.buttonexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonexit.Location = new System.Drawing.Point(602, 363);
            this.buttonexit.Name = "buttonexit";
            this.buttonexit.Size = new System.Drawing.Size(199, 69);
            this.buttonexit.TabIndex = 2;
            this.buttonexit.Text = "EXIT";
            this.buttonexit.UseVisualStyleBackColor = true;
            this.buttonexit.Click += new System.EventHandler(this.buttonexit_Click);
            // 
            // buttonrestart
            // 
            this.buttonrestart.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonrestart.Location = new System.Drawing.Point(234, 363);
            this.buttonrestart.Name = "buttonrestart";
            this.buttonrestart.Size = new System.Drawing.Size(199, 69);
            this.buttonrestart.TabIndex = 1;
            this.buttonrestart.Text = "RESTART";
            this.buttonrestart.UseVisualStyleBackColor = true;
            this.buttonrestart.Click += new System.EventHandler(this.buttonrestart_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Gothic", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(221, 209);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(710, 120);
            this.label1.TabIndex = 0;
            this.label1.Tag = "win";
            this.label1.Text = "YOU WIN !!!";
            // 
            // huruf5cover
            // 
            this.huruf5cover.AutoSize = true;
            this.huruf5cover.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf5cover.Location = new System.Drawing.Point(613, 20);
            this.huruf5cover.Name = "huruf5cover";
            this.huruf5cover.Size = new System.Drawing.Size(69, 76);
            this.huruf5cover.TabIndex = 38;
            this.huruf5cover.Text = "_";
            // 
            // huruf4cover
            // 
            this.huruf4cover.AutoSize = true;
            this.huruf4cover.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf4cover.Location = new System.Drawing.Point(532, 19);
            this.huruf4cover.Name = "huruf4cover";
            this.huruf4cover.Size = new System.Drawing.Size(69, 76);
            this.huruf4cover.TabIndex = 37;
            this.huruf4cover.Text = "_";
            // 
            // huruf3cover
            // 
            this.huruf3cover.AutoSize = true;
            this.huruf3cover.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf3cover.Location = new System.Drawing.Point(451, 20);
            this.huruf3cover.Name = "huruf3cover";
            this.huruf3cover.Size = new System.Drawing.Size(69, 76);
            this.huruf3cover.TabIndex = 36;
            this.huruf3cover.Text = "_";
            // 
            // huruf2cover
            // 
            this.huruf2cover.AutoSize = true;
            this.huruf2cover.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf2cover.Location = new System.Drawing.Point(372, 20);
            this.huruf2cover.Name = "huruf2cover";
            this.huruf2cover.Size = new System.Drawing.Size(69, 76);
            this.huruf2cover.TabIndex = 35;
            this.huruf2cover.Text = "_";
            // 
            // huruf1cover
            // 
            this.huruf1cover.AutoSize = true;
            this.huruf1cover.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf1cover.Location = new System.Drawing.Point(288, 20);
            this.huruf1cover.Name = "huruf1cover";
            this.huruf1cover.Size = new System.Drawing.Size(69, 76);
            this.huruf1cover.TabIndex = 34;
            this.huruf1cover.Text = "_";
            // 
            // buttonM
            // 
            this.buttonM.Location = new System.Drawing.Point(647, 307);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(75, 75);
            this.buttonM.TabIndex = 33;
            this.buttonM.Text = "M";
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.buttonM_Click);
            // 
            // buttonN
            // 
            this.buttonN.Location = new System.Drawing.Point(566, 307);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(75, 75);
            this.buttonN.TabIndex = 32;
            this.buttonN.Text = "N";
            this.buttonN.UseVisualStyleBackColor = true;
            this.buttonN.Click += new System.EventHandler(this.buttonN_Click);
            // 
            // buttonB
            // 
            this.buttonB.Location = new System.Drawing.Point(485, 307);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(75, 75);
            this.buttonB.TabIndex = 31;
            this.buttonB.Text = "B";
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.buttonB_Click);
            // 
            // buttonV
            // 
            this.buttonV.Location = new System.Drawing.Point(403, 307);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(75, 75);
            this.buttonV.TabIndex = 30;
            this.buttonV.Text = "V";
            this.buttonV.UseVisualStyleBackColor = true;
            this.buttonV.Click += new System.EventHandler(this.buttonV_Click);
            // 
            // buttonC
            // 
            this.buttonC.Location = new System.Drawing.Point(322, 307);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(75, 75);
            this.buttonC.TabIndex = 29;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonX
            // 
            this.buttonX.Location = new System.Drawing.Point(241, 307);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(75, 75);
            this.buttonX.TabIndex = 28;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonZ
            // 
            this.buttonZ.Location = new System.Drawing.Point(160, 307);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(75, 75);
            this.buttonZ.TabIndex = 27;
            this.buttonZ.Text = "Z";
            this.buttonZ.UseVisualStyleBackColor = true;
            this.buttonZ.Click += new System.EventHandler(this.buttonZ_Click);
            // 
            // buttonL
            // 
            this.buttonL.Location = new System.Drawing.Point(764, 226);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(75, 75);
            this.buttonL.TabIndex = 26;
            this.buttonL.Text = "L";
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.buttonL_Click);
            // 
            // buttonK
            // 
            this.buttonK.Location = new System.Drawing.Point(683, 226);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(75, 75);
            this.buttonK.TabIndex = 25;
            this.buttonK.Text = "K";
            this.buttonK.UseVisualStyleBackColor = true;
            this.buttonK.Click += new System.EventHandler(this.buttonK_Click);
            // 
            // buttonJ
            // 
            this.buttonJ.Location = new System.Drawing.Point(602, 226);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(75, 75);
            this.buttonJ.TabIndex = 24;
            this.buttonJ.Text = "J";
            this.buttonJ.UseVisualStyleBackColor = true;
            this.buttonJ.Click += new System.EventHandler(this.buttonJ_Click);
            // 
            // buttonH
            // 
            this.buttonH.Location = new System.Drawing.Point(521, 226);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(75, 75);
            this.buttonH.TabIndex = 23;
            this.buttonH.Text = "H";
            this.buttonH.UseVisualStyleBackColor = true;
            this.buttonH.Click += new System.EventHandler(this.buttonH_Click);
            // 
            // buttonG
            // 
            this.buttonG.Location = new System.Drawing.Point(440, 226);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(75, 75);
            this.buttonG.TabIndex = 22;
            this.buttonG.Text = "G";
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // buttonF
            // 
            this.buttonF.Location = new System.Drawing.Point(358, 226);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(75, 75);
            this.buttonF.TabIndex = 21;
            this.buttonF.Text = "F";
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonD
            // 
            this.buttonD.Location = new System.Drawing.Point(277, 226);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(75, 75);
            this.buttonD.TabIndex = 20;
            this.buttonD.Text = "D";
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // buttonS
            // 
            this.buttonS.Location = new System.Drawing.Point(196, 226);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(75, 75);
            this.buttonS.TabIndex = 19;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
            // 
            // buttonA
            // 
            this.buttonA.Location = new System.Drawing.Point(115, 226);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(75, 75);
            this.buttonA.TabIndex = 18;
            this.buttonA.Text = "A";
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
            // 
            // buttonP
            // 
            this.buttonP.Location = new System.Drawing.Point(809, 145);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(75, 75);
            this.buttonP.TabIndex = 17;
            this.buttonP.Text = "P";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // buttonO
            // 
            this.buttonO.Location = new System.Drawing.Point(728, 145);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(75, 75);
            this.buttonO.TabIndex = 16;
            this.buttonO.Text = "O";
            this.buttonO.UseVisualStyleBackColor = true;
            this.buttonO.Click += new System.EventHandler(this.buttonO_Click);
            // 
            // buttonI
            // 
            this.buttonI.Location = new System.Drawing.Point(647, 145);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(75, 75);
            this.buttonI.TabIndex = 15;
            this.buttonI.Text = "I";
            this.buttonI.UseVisualStyleBackColor = true;
            this.buttonI.Click += new System.EventHandler(this.buttonI_Click);
            // 
            // buttonU
            // 
            this.buttonU.Location = new System.Drawing.Point(566, 145);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(75, 75);
            this.buttonU.TabIndex = 14;
            this.buttonU.Text = "U";
            this.buttonU.UseVisualStyleBackColor = true;
            this.buttonU.Click += new System.EventHandler(this.buttonU_Click);
            // 
            // buttonY
            // 
            this.buttonY.Location = new System.Drawing.Point(485, 145);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(75, 75);
            this.buttonY.TabIndex = 13;
            this.buttonY.Text = "Y";
            this.buttonY.UseVisualStyleBackColor = true;
            this.buttonY.Click += new System.EventHandler(this.buttonY_Click);
            // 
            // buttonT
            // 
            this.buttonT.Location = new System.Drawing.Point(404, 145);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(75, 75);
            this.buttonT.TabIndex = 12;
            this.buttonT.Text = "T";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonR
            // 
            this.buttonR.Location = new System.Drawing.Point(322, 145);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(75, 75);
            this.buttonR.TabIndex = 11;
            this.buttonR.Text = "R";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // buttonE
            // 
            this.buttonE.Location = new System.Drawing.Point(241, 145);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(75, 75);
            this.buttonE.TabIndex = 10;
            this.buttonE.Text = "E";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.ButtonE_Click);
            // 
            // buttonW
            // 
            this.buttonW.Location = new System.Drawing.Point(160, 145);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(75, 75);
            this.buttonW.TabIndex = 9;
            this.buttonW.Text = "W";
            this.buttonW.UseVisualStyleBackColor = true;
            this.buttonW.Click += new System.EventHandler(this.buttonW_Click);
            // 
            // buttonQ
            // 
            this.buttonQ.Location = new System.Drawing.Point(79, 145);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(75, 75);
            this.buttonQ.TabIndex = 8;
            this.buttonQ.Text = "Q";
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.buttonQ_Click);
            // 
            // huruf5
            // 
            this.huruf5.AutoSize = true;
            this.huruf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf5.Location = new System.Drawing.Point(614, 27);
            this.huruf5.Name = "huruf5";
            this.huruf5.Size = new System.Drawing.Size(63, 69);
            this.huruf5.TabIndex = 7;
            this.huruf5.Text = "_";
            // 
            // huruf4
            // 
            this.huruf4.AutoSize = true;
            this.huruf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf4.Location = new System.Drawing.Point(533, 27);
            this.huruf4.Name = "huruf4";
            this.huruf4.Size = new System.Drawing.Size(63, 69);
            this.huruf4.TabIndex = 6;
            this.huruf4.Text = "_";
            // 
            // huruf3
            // 
            this.huruf3.AutoSize = true;
            this.huruf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf3.Location = new System.Drawing.Point(452, 27);
            this.huruf3.Name = "huruf3";
            this.huruf3.Size = new System.Drawing.Size(63, 69);
            this.huruf3.TabIndex = 5;
            this.huruf3.Text = "_";
            // 
            // huruf2
            // 
            this.huruf2.AutoSize = true;
            this.huruf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf2.Location = new System.Drawing.Point(373, 27);
            this.huruf2.Name = "huruf2";
            this.huruf2.Size = new System.Drawing.Size(63, 69);
            this.huruf2.TabIndex = 4;
            this.huruf2.Text = "_";
            // 
            // huruf1
            // 
            this.huruf1.AutoSize = true;
            this.huruf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.huruf1.Location = new System.Drawing.Point(289, 27);
            this.huruf1.Name = "huruf1";
            this.huruf1.Size = new System.Drawing.Size(63, 69);
            this.huruf1.TabIndex = 3;
            this.huruf1.Text = "_";
            // 
            // gametime
            // 
            this.gametime.Enabled = true;
            this.gametime.Interval = 20;
            this.gametime.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // backbutton
            // 
            this.backbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backbutton.Location = new System.Drawing.Point(92, 454);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(120, 42);
            this.backbutton.TabIndex = 3;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // answer
            // 
            this.answer.AutoSize = true;
            this.answer.Location = new System.Drawing.Point(713, 100);
            this.answer.Name = "answer";
            this.answer.Size = new System.Drawing.Size(0, 20);
            this.answer.TabIndex = 40;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 562);
            this.Controls.Add(this.panelwin);
            this.Controls.Add(this.panelutama);
            this.Controls.Add(this.panelmain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Game by Adelio Surya Putra Pratama";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelutama.ResumeLayout(false);
            this.panelutama.PerformLayout();
            this.panelmain.ResumeLayout(false);
            this.panelmain.PerformLayout();
            this.panelwin.ResumeLayout(false);
            this.panelwin.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox boxkata1;
        private System.Windows.Forms.Label labelkata1;
        private System.Windows.Forms.Label instruksi;
        private System.Windows.Forms.Label labelkata2;
        private System.Windows.Forms.TextBox boxkata2;
        private System.Windows.Forms.Label labelkata3;
        private System.Windows.Forms.TextBox boxkata3;
        private System.Windows.Forms.Label labelkata4;
        private System.Windows.Forms.TextBox boxkata4;
        private System.Windows.Forms.Label labelkata5;
        private System.Windows.Forms.TextBox boxkata5;
        private System.Windows.Forms.Button startbutton;
        private System.Windows.Forms.Panel panelutama;
        private System.Windows.Forms.Panel panelmain;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Label huruf5;
        private System.Windows.Forms.Label huruf4;
        private System.Windows.Forms.Label huruf3;
        private System.Windows.Forms.Label huruf2;
        private System.Windows.Forms.Label huruf1;
        private System.Windows.Forms.Label huruf5cover;
        private System.Windows.Forms.Label huruf4cover;
        private System.Windows.Forms.Label huruf3cover;
        private System.Windows.Forms.Label huruf2cover;
        private System.Windows.Forms.Label huruf1cover;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Timer gametime;
        private System.Windows.Forms.Panel panelwin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonexit;
        private System.Windows.Forms.Button buttonrestart;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Label answer;
    }
}

